import {
    AppRegistry
} from 'react-native';
import secondStudy from './WeatherProject';

AppRegistry.registerComponent('secondStudy', () => secondStudy);